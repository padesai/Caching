#include "ns3/point-to-point-helper.h"
#include "ns3/point-to-point-star.h"
#include "ns3/ipv4-address-helper.h"
#include "ns3/ipv6-address-helper.h"
#include "ns3/internet-stack-helper.h"
#include "ns3/internet-module.h"
#include "ns3/internet-apps-module.h"
#include "ns3/ipv4-interface-container.h"
#include "ns3/ipv6-interface-container.h"
#include "ns3/random-variable-stream.h"
#include "ns3/ipv4-nix-vector-helper.h"
#include "ns3/string.h"
#include "ns3/double.h"
#include "ns3/applications-module.h"
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/ipv4-static-routing-helper.h"
#include "ns3/ipv4-list-routing-helper.h"
#include "ns3/ipv4-nix-vector-helper.h"

#include <map>

using namespace ns3;

class PointToPointCampusHelper
{
public:

  PointToPointCampusHelper(uint32_t nSpokes, PointToPointHelper pointToPoint);

  ~PointToPointCampusHelper();

  NetDeviceContainer devices;

};


PointToPointCampusHelper::PointToPointCampusHelper(uint32_t nSpokes, PointToPointHelper pointToPoint)
{

  NodeContainer node;
  node.Create(1);

	  //allNodes.Create(1);  // create the hub node
	  //nodeInfoList[nodeNum].node = allNodes.Get(0);
	  //nodeInfoList[nodeNum].server = true;
	  //nodeNum+=1;

  InternetStackHelper stack;
  stack.Install(node);

  static int32_t ipAddressCountHubs = 15;
  static int32_t ipAddressCount = -1;
  	
  PointToPointStarHelper stars[16] = PointToPointStarHelper(nSpokes,pointToPoint);

  PointToPointHelper pointToPointCentralNode;
  pointToPointCentralNode.SetDeviceAttribute("DataRate", StringValue("1Mbps"));
  pointToPointCentralNode.SetChannelAttribute("Delay", StringValue("2ms"));


  for (int i = 0; i < 16; i++) {
	  
	  //PointToPointStarHelper star1(nSpokes, pointToPoint);
	  //PointToPointStarHelper star2(nSpokes, pointToPoint);
	  //PointToPointStarHelper star3(nSpokes, pointToPoint);
	  //PointToPointStarHelper star4(nSpokes, pointToPoint);
	  //PointToPointStarHelper star5(nSpokes, pointToPoint);
	  //PointToPointStarHelper star6(nSpokes, pointToPoint);
	  //PointToPointStarHelper star7(nSpokes, pointToPoint);
	  //PointToPointStarHelper star8(nSpokes, pointToPoint);
	  //PointToPointStarHelper star9(nSpokes, pointToPoint);
	  //PointToPointStarHelper star10(nSpokes, pointToPoint);
	  //PointToPointStarHelper star11(nSpokes, pointToPoint);
	  //PointToPointStarHelper star12(nSpokes, pointToPoint);
	  //PointToPointStarHelper star13(nSpokes, pointToPoint);
	  //PointToPointStarHelper star14(nSpokes, pointToPoint);
	  //PointToPointStarHelper star15(nSpokes, pointToPoint);
	  //PointToPointStarHelper star16(nSpokes, pointToPoint);

	stars[i].InstallStack(stack);

	  //star1.InstallStack(internet);
	  //star2.InstallStack(internet);
	  //star3.InstallStack(internet);
	  //star4.InstallStack(internet); 
	  //star5.InstallStack(internet);
	  //star6.InstallStack(internet);
	  //star7.InstallStack(internet);
	  //star8.InstallStack(internet);
	  //star9.InstallStack(internet);
	  //star10.InstallStack(internet);
	  //star11.InstallStack(internet);
	  //star12.InstallStack(internet);
	  //star13.InstallStack(internet);
	  //star14.InstallStack(internet);
	  //star15.InstallStack(internet);
	  //star16.InstallStack(internet);

	Ipv4AddressHelper address;
	ipAddressCount++;
	address.SetBase(("10." + std::to_string(ipAddressCount) + ".1.0").c_str(), "255.255.255.0");

	/*
	  Ipv4AddressHelper address1("10.1.1.0", "255.255.255.0");
	  Ipv4AddressHelper address2("10.2.1.0", "255.255.255.0");
	  Ipv4AddressHelper address3("10.3.1.0", "255.255.255.0");
	  Ipv4AddressHelper address4("10.4.1.0", "255.255.255.0");
	  Ipv4AddressHelper address5("10.5.1.0", "255.255.255.0");
	  Ipv4AddressHelper address6("10.6.1.0", "255.255.255.0");  
	  Ipv4AddressHelper address7("10.7.1.0", "255.255.255.0");
	  Ipv4AddressHelper address8("10.8.1.0", "255.255.255.0");
	  Ipv4AddressHelper address9("10.9.1.0", "255.255.255.0");
	  Ipv4AddressHelper address10("10.10.1.0", "255.255.255.0");
	  Ipv4AddressHelper address11("10.11.1.0", "255.255.255.0");
	  Ipv4AddressHelper address12("10.12.1.0", "255.255.255.0");
	  Ipv4AddressHelper address13("10.13.1.0", "255.255.255.0");
	  Ipv4AddressHelper address14("10.14.1.0", "255.255.255.0");
	  Ipv4AddressHelper address15("10.15.1.0", "255.255.255.0");
	  Ipv4AddressHelper address16("10.16.1.0", "255.255.255.0");

	  Ipv4AddressHelper address17;
	  address17.SetBase ("10.17.1.0", "255.255.255.0");

	  Ipv4AddressHelper address18;
	  address18.SetBase ("10.18.1.0", "255.255.255.0");

	  Ipv4AddressHelper address19;
	  address19.SetBase ("10.19.1.0", "255.255.255.0");

	  Ipv4AddressHelper address20;
	  address20.SetBase ("10.20.1.0", "255.255.255.0");

	  Ipv4AddressHelper address21;
	  address21.SetBase ("10.21.1.0", "255.255.255.0");

	  Ipv4AddressHelper address22;
	  address22.SetBase ("10.22.1.0", "255.255.255.0");

	  Ipv4AddressHelper address23;
	  address23.SetBase ("10.23.1.0", "255.255.255.0");

	  Ipv4AddressHelper address24;
	  address24.SetBase ("10.24.1.0", "255.255.255.0");

	  Ipv4AddressHelper address25;
	  address25.SetBase ("10.25.1.0", "255.255.255.0");

	  Ipv4AddressHelper address26;
	  address19.SetBase ("10.26.1.0", "255.255.255.0");

	  Ipv4AddressHelper address27;
	  address19.SetBase ("10.27.1.0", "255.255.255.0");

	  Ipv4AddressHelper address28;
	  address19.SetBase ("10.28.1.0", "255.255.255.0");

	  Ipv4AddressHelper address29;
	  address19.SetBase ("10.29.1.0", "255.255.255.0");

	  Ipv4AddressHelper address30;
	  address19.SetBase ("10.30.1.0", "255.255.255.0");

	  Ipv4AddressHelper address31;
	  address19.SetBase ("10.31.1.0", "255.255.255.0");

	  Ipv4AddressHelper address32;
	  address19.SetBase ("10.32.1.0", "255.255.255.0");
	*/

	stars[i].AssignIpv4Addresses(address);
		//star1.AssignIpv4Addresses(address1);
		//star2.AssignIpv4Addresses(address2);
		//star3.AssignIpv4Addresses(address3);
		//star4.AssignIpv4Addresses(address4);
		//star5.AssignIpv4Addresses(address5);
		//star6.AssignIpv4Addresses(address6);
		//star7.AssignIpv4Addresses(address7);
		//star8.AssignIpv4Addresses(address8);
		//star9.AssignIpv4Addresses(address9);
		//star10.AssignIpv4Addresses(address10);
		//star11.AssignIpv4Addresses(address11);
		//star12.AssignIpv4Addresses(address12);
		//star13.AssignIpv4Addresses(address13);
		//star14.AssignIpv4Addresses(address14);
		//star15.AssignIpv4Addresses(address15);
		//star16.AssignIpv4Addresses(address16);

	NetDeviceContainer p2pCentralNode;
	//Create links between each star and the central node        
	p2pCentralNode = pointToPointCentralNode.Install(stars[i].GetHub(),node.Get(0));
	devices.Add(p2pCentralNode);
	//Assign IP Addresses to the links between each star and the central node
	Ipv4AddressHelper address1;
	ipAddressCountHubs++;
	address1.SetBase(("10." + std::to_string(ipAddressCountHubs) + ".1.0").c_str(), "255.255.255.0");
	address1.Assign(p2pCentralNode);

}

	//NetDeviceContainer p2pCentralNode1;
	//NetDeviceContainer p2pCetnralNode2;
	//NetDeviceContainer p2pCentralNode3;
        //NetDeviceContainer p2pCentralNode4;
	//NetDeviceContainer p2pCentralNode5;
	//NetDeviceContainer p2pCetnralNode6;
	//NetDeviceContainer p2pCentralNode7;
        //NetDeviceContainer p2pCentralNode8;
	//NetDeviceContainer p2pCentralNode9;
	//NetDeviceContainer p2pCetnralNode10;
	//NetDeviceContainer p2pCentralNode11;
        //NetDeviceContainer p2pCentralNode12;
	//NetDeviceContainer p2pCentralNode13;
	//NetDeviceContainer p2pCetnralNode14;
	//NetDeviceContainer p2pCentralNode15;
        //NetDeviceContainer p2pCentralNode16;

	//Create links between each star and the central node
	//p2pCentralNode1 = pointToPointCentralNode.Install(star1.GetHub(),node.Get(0));
        //p2pCentralNode2 = pointToPointCentralNode.Install(star2.GetHub(),node.Get(0));
	//p2pCentralNode3 = pointToPointCentralNode.Install(star3.GetHub(),node.Get(0));
        //p2pCentralNode4 = pointToPointCentralNode.Install(star4.GetHub(),node.Get(0));
	//p2pCentralNode5 = pointToPointCentralNode.Install(star5.GetHub(),node.Get(0));
	//p2pCentralNode6 = pointToPointCentralNode.Install(star6.GetHub(),node.Get(0));
	//p2pCentralNode7 = pointToPointCentralNode.Install(star7.GetHub(),node.Get(0));
        //p2pCentralNode8 = pointToPointCentralNode.Install(star8.GetHub(),node.Get(0));
	//p2pCentralNode9 = pointToPointCentralNode.Install(star9.GetHub(),node.Get(0));
	//p2pCentralNode10 = pointToPointCentralNode.Install(star10.GetHub(),node.Get(0));
	//p2pCentralNode11 = pointToPointCentralNode.Install(star11.GetHub(),node.Get(0));
        //p2pCentralNode12 = pointToPointCentralNode.Install(star12.GetHub(),node.Get(0));
	//p2pCentralNode13 = pointToPointCentralNode.Install(star13.GetHub(),node.Get(0));
	//p2pCentralNode14 = pointToPointCentralNode.Install(star14.GetHub(),node.Get(0));
	//p2pCentralNode15 = pointToPointCentralNode.Install(star15.GetHub(),node.Get(0));
        //p2pCentralNode16 = pointToPointCentralNode.Install(star16.GetHub(),node.Get(0));
	  
        //Assign IP Addresses to the links between each star and the central node
	//address17.Assign(p2pCentralNode1);
        //address18.Assign(p2pCentralNode2);
	//address19.Assign(p2pCentralNode3);
        //address20.Assign(p2pCentralNode4);
        //address21.Assign(p2pCentralNode5);
        //address22.Assign(p2pCentralNode6);
	//address23.Assign(p2pCentralNode7);
        //address24.Assign(p2pCentralNode8);
	//address25.Assign(p2pCentralNode9);
        //address26.Assign(p2pCentralNode10);
	//address27.Assign(p2pCentralNode11);
        //address28.Assign(p2pCentralNode12);
	//address29.Assign(p2pCentralNode13);
        //address30.Assign(p2pCentralNode14);
	//address31.Assign(p2pCentralNode15);
        //address32.Assign(p2pCentralNode16);  


 std::cout << " -------------------------------------------------- " << std::endl;

}

PointToPointCampusHelper::~PointToPointCampusHelper()
{
}
