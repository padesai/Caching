#include <iostream>
#include <sstream>
#include <chrono>

#include "p2pCampusHelper.h"
#include "ns3/mpi-interface.h"


int main(int argc, char** argv)
{

  std::string hubToCentralLinkBW = "100Mbps";
  std::string hubToCentralLinkDelay = "100ms";

  PointToPointHelper p2pHelper;
  p2pHelper.SetDeviceAttribute ("DataRate", StringValue(hubToCentralLinkBW));
  p2pHelper.SetChannelAttribute ("Delay", StringValue(hubToCentralLinkDelay));

  PointToPointCampusHelper p2pCampusHelper(64,p2pHelper);

  Ipv4GlobalRoutingHelper::PopulateRoutingTables();

  std::cout << "Hello" << std::endl;
 
  //Simulator::Run();

  //Simulator::Destroy();

  return 0;

}
