#include "ns3/point-to-point-helper.h"
#include "ns3/point-to-point-star.h"
#include "ns3/ipv4-address-helper.h"
#include "ns3/ipv6-address-helper.h"
#include "ns3/internet-stack-helper.h"
#include "ns3/internet-module.h"
#include "ns3/internet-apps-module.h"
#include "ns3/ipv4-interface-container.h"
#include "ns3/ipv6-interface-container.h"
#include "ns3/random-variable-stream.h"
#include "ns3/ipv4-nix-vector-helper.h"
#include "ns3/string.h"
#include "ns3/double.h"
#include "ns3/applications-module.h"
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/ipv4-static-routing-helper.h"
#include "ns3/ipv4-list-routing-helper.h"
#include "ns3/ipv4-nix-vector-helper.h"

#include <map>
#include <vector>

using namespace ns3;

typedef uint32_t FileId_t;
typedef uint32_t NumOfAccesses_t;
typedef uint64_t TimeStamp_t;
typedef std::map<FileId_t, std::pair<NumOfAccesses_t, TimeStamp_t>> FileCacheTable_t;


struct StarInfo
{

  StarInfo()
   : starHelper(64  , PointToPointHelper())
   , fileCache()
   , starNumber(0)
   , totalAccessDelay(0)
   , currentTimeStamp(0)
   , MAX_CACHE_SIZE(0)
   , totalHits(0)
   , totalMisses(0)
   , mruAccess(0)
   , missDelay(0)
   , hitDelay(0)
  {
  }

  void flushFileCache()
  {
  	fileCache.clear();
  }

  void accessFileCache(FileId_t fileId)
  {
    currentTimeStamp++;
    if (fileCache.end() == fileCache.find(fileId))  // item not cached
    {
       if (isCacheFull())
       {
       	 evictCacheItem();
       }	     
       fileCache[fileId] = std::make_pair<NumOfAccesses_t, TimeStamp_t>(0, 0);
       totalMisses += 1;
    }
    else 
    {
       totalHits += 1;
    }
    fileCache[fileId].first++;
    fileCache[fileId].second = currentTimeStamp;
    mruAccess = fileId;
  }
  
  uint64_t getTotalDelay()
  {
    totalAccessDelay = (hitDelay * (totalHits + totalMisses)) + (totalMisses * missDelay);
    return totalAccessDelay;
  }

  bool isCacheFull()
  {
    return fileCache.size() >= MAX_CACHE_SIZE;
  } 

  void evictCacheItem()
  {
    fileCache.erase(mruAccess);
  }
  
  PointToPointStarHelper starHelper;
  FileCacheTable_t fileCache;
  
  uint32_t starNumber;
  uint32_t totalAccessDelay;
  uint64_t currentTimeStamp;
  uint32_t MAX_CACHE_SIZE;
  uint64_t totalHits;
  uint64_t totalMisses;
  FileId_t mruAccess;
  
  uint32_t missDelay;
  uint32_t hitDelay;
};


class PointToPointCampusHelper
{
public:

  PointToPointCampusHelper();

  ~PointToPointCampusHelper();
 
  uint64_t getTotalDelay();
  void setServerInfo(PointToPointHelper p2pServerHub, uint32_t numOfStars);
  void setStarInfo(PointToPointHelper p2pHubSpoke, uint32_t numOfSpokesPerStar_);

  void createMemCacheTopology();
  
  friend void receiveCallBack(int starId, FileId_t fileId, PointToPointCampusHelper *p2p, Ptr<const Packet> item);
  void initStarInfo(uint32_t starNumber, PointToPointHelper p2pStar, InternetStackHelper& stack);

  NetDeviceContainer devices_;

  std::vector<StarInfo> starInfoList_;
  Ipv4InterfaceContainer interfaces;

  FileCacheTable_t globalFileStore_;

  uint32_t fileCacheSize_;
  uint32_t spokeToStarHubDelay_;
  uint32_t hubToCentralServerDelay_;
  uint32_t numOfSpokesPerStar_;
  uint32_t numOfStars_;
  PointToPointHelper p2pServerHub_;
  PointToPointHelper p2pHubSpoke_;
};

inline void receiveCallBack(int starId, FileId_t fileId, PointToPointCampusHelper *p2p, Ptr<const Packet> item) 
{
  std::cout << "receive" << std::endl;
  p2p->starInfoList_[starId].accessFileCache(fileId);
}

inline void PointToPointCampusHelper::setServerInfo(PointToPointHelper p2pServerHub, uint32_t numOfStars)
{
  p2pServerHub_ = p2pServerHub;
  numOfStars_ = numOfStars;
}

inline void PointToPointCampusHelper::setStarInfo(PointToPointHelper p2pHubSpoke, uint32_t numOfSpokesPerStar)
{ 
  p2pHubSpoke_ = p2pHubSpoke;
  numOfSpokesPerStar_ = numOfSpokesPerStar;
}

inline void PointToPointCampusHelper::initStarInfo(uint32_t starNumber, PointToPointHelper p2pStar, InternetStackHelper& stack)
{
  starInfoList_[starNumber].MAX_CACHE_SIZE = fileCacheSize_;
  starInfoList_[starNumber].missDelay = hubToCentralServerDelay_;
  starInfoList_[starNumber].hitDelay = spokeToStarHubDelay_;
  starInfoList_[starNumber].starNumber = starNumber;
 // starInfoList_[starNumber].starHelper = PointToPointStarHelper(numOfSpokesPerStar_, p2pStar);
  starInfoList_[starNumber].starHelper.InstallStack(stack);

}


inline void PointToPointCampusHelper::createMemCacheTopology()
{
  std::cout << "Creating Mem Cache topology ..... \n";	
  NodeContainer node;
  node.Create(1);

  InternetStackHelper stack;
  stack.Install(node);

  starInfoList_.resize(numOfStars_);

  uint16_t portServer = 5000;
  uint16_t portClient = 4000;
  ApplicationContainer serverApps;
  ApplicationContainer clientApps;
  uint32_t MaxPacketSize = 1024;
  Time interPacketInterval = Seconds (0.05);
  uint32_t maxPacketCount = 320;

  NetDeviceContainer p2pCentralNetDevices;

  for (uint32_t starNum = 0; starNum < numOfStars_; ++starNum)
  {
  	StarInfo& starInfo = starInfoList_[starNum];

        initStarInfo(starNum, p2pHubSpoke_, stack);

	Ipv4AddressHelper address;

	address.SetBase(("10." + std::to_string(starNum+1) + ".1.0").c_str(), "255.255.255.0");
        
	
	starInfo.starHelper.AssignIpv4Addresses(address);

	//Create links between each star and the central node        
	p2pCentralNetDevices = p2pServerHub_.Install(starInfo.starHelper.GetHub(),node.Get(0));
	devices_.Add(p2pCentralNetDevices);

	//Assign IP Addresses to the links between each star and the central node
	Ipv4AddressHelper address1;

	address1.SetBase(("10." + std::to_string(starNum+200) + ".1.0").c_str(), "255.255.255.0");
	
	Ipv4InterfaceContainer interfaces = address1.Assign(p2pCentralNetDevices);
        std::cout << "Server IP -- " << p2pCentralNetDevices.Get(1)->GetAddress() << std::endl;
 	std::cout << "Hub IP -- " << p2pCentralNetDevices.Get(0)->GetAddress() << std::endl;

	if (starNum == 0) {
        	UdpServerHelper server(portServer);
        	serverApps = server.Install(node.Get(0));
	}

	UdpClientHelper client (interfaces.GetAddress(1), portServer);
	client.SetAttribute ("MaxPackets", UintegerValue (maxPacketCount));	
	client.SetAttribute ("Interval", TimeValue (interPacketInterval));
	client.SetAttribute ("PacketSize", UintegerValue (MaxPacketSize));
	client.Install(starInfo.starHelper.GetHub());

	UdpServerHelper server(portClient);
   	serverApps = server.Install(starInfo.starHelper.GetHub());


	//FileId_t fId = 1;

  	FileId_t fId = 1;
  	p2pCentralNetDevices.Get(0)->TraceConnectWithoutContext("PhyTxBegin", MakeBoundCallback(&receiveCallBack, starNum, fId, this));
	

	for (uint32_t j = 0; j < numOfSpokesPerStar_; j++) {
		client = UdpClientHelper(starInfo.starHelper.GetHubIpv4Address(j), portClient);
		client.SetAttribute ("MaxPackets", UintegerValue (maxPacketCount));	
		client.SetAttribute ("Interval", TimeValue (interPacketInterval));
		client.SetAttribute ("PacketSize", UintegerValue (MaxPacketSize));	
		clientApps = client.Install(starInfo.starHelper.GetSpokeNode(j));
		std::cout << starInfo.starHelper.GetSpokeIpv4Address(j) << std::endl;
		std::cout << "Hub IP: " << starInfo.starHelper.GetHubIpv4Address(j) << std::endl;

	}
	
	
  }

  serverApps.Start (Seconds (1.0));
  serverApps.Stop (Seconds (10.0));
  clientApps.Start (Seconds (2.0));
  clientApps.Stop (Seconds (10.0));

  std::cout << "Mem Cache topology created and initalized ..... \n";
}

inline uint64_t PointToPointCampusHelper::getTotalDelay()
{
  uint64_t totalAccessDelay = 0;
  for (uint32_t i = 0; i < starInfoList_.size(); ++i)
  {
    totalAccessDelay += starInfoList_[i].totalAccessDelay;
  }
  return totalAccessDelay;
}


inline PointToPointCampusHelper::PointToPointCampusHelper()
  : devices_()
  , starInfoList_()
  , globalFileStore_()
  , fileCacheSize_(0)
  , spokeToStarHubDelay_(0)
  , hubToCentralServerDelay_(0)
  , numOfSpokesPerStar_(0)
  , numOfStars_(0)
  , p2pServerHub_()
  , p2pHubSpoke_()
{
}

PointToPointCampusHelper::~PointToPointCampusHelper()
{
}
