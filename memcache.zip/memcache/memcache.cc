#include <iostream>
#include <sstream>
#include <chrono>

#include "p2pCampusHelper.h"
#include "ns3/mpi-interface.h"

const uint32_t numOfStars = 16;
const uint32_t numOfSpokesPerStar = 64;

std::string hubToServerBW = "100Mbps";
std::string hubToServerDelay = "100ms";

std::string spokeToHubBW = "100Mbps";
std::string spokeToHubDelay = "2ms";

int main(int argc, char** argv)
{
  PointToPointCampusHelper p2pCampusHelper;

  std::cout << "1" << std::endl;

  PointToPointHelper p2pServerHub;
  p2pServerHub.SetDeviceAttribute ("DataRate", StringValue(hubToServerBW));
  p2pServerHub.SetChannelAttribute ("Delay", StringValue(hubToServerDelay));
  p2pCampusHelper.setServerInfo(p2pServerHub, numOfStars);
  

  PointToPointHelper p2pHubSpoke;
  p2pHubSpoke.SetDeviceAttribute ("DataRate", StringValue(spokeToHubBW));
  p2pHubSpoke.SetChannelAttribute ("Delay", StringValue(spokeToHubDelay));
  p2pCampusHelper.setStarInfo(p2pHubSpoke, numOfSpokesPerStar);
  
  p2pCampusHelper.createMemCacheTopology();

  Ipv4GlobalRoutingHelper::PopulateRoutingTables();

  std::cout << "Hello" << std::endl;
  Simulator::Stop(Seconds(10.0));  

  Simulator::Run();

  Simulator::Destroy();

  return 0;

}
